var fs = require('fs'); 
var express = require('express'); 
var multer  = require('multer') 
var path = require('path')
 
var app = express(); 

app.use(express.static(path.join(__dirname, 'public')))

const storage = multer.diskStorage({
	  destination: function (req, file, cb) {
	    cb(null, path.resolve('public/uploads'));
	  },
	  filename: function (req, file, cb) {
	    cb(null, Date.now() + path.extname(file.originalname));
	  }
	});

var upload = multer({storage: storage});

app.post('/upload', upload.single('avatar'), function(req, res, next) {

	res.send({
	    err: null,
	    filePath: 'uploads/' + path.basename(req.file.path)
	  });
	var file = req.file;
	console.log('文件类型：%s', file.mimetype);
	 
	if(file.mimetype="application/zip"){
fs.createReadStream('uploads/'+ path.basename(req.file.path)).pipe(unzip.Extract({ path: 'output/path' }));
	}

	});
  
app.listen(3000, function () {
	console.log('app listening on port 3000!')

	})
